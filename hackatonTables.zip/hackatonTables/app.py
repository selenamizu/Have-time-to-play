#Импорт библиотек
import numpy as np
from flask import Flask, render_template,request
import pandas as pd
app = Flask(__name__)
  
  
# reading the data in the csv file
df = pd.read_csv('plan.csv')
df.to_csv('plan.csv', index=None)
dfFirst = df.head(7)
dfsecond = df.tail(len(df) - 7)


@app.route('/')
@app.route('/table')
def table():
    
    # converting csv to html
    data = pd.read_csv('plan.csv')
    dataFirst = data.head(7)
    dataSecond = data.tail(len(data) - 7)
    return render_template('index.html', tables=[dataFirst.to_html()], tables2 =[dataSecond.to_html()], titles=[''])

    
if __name__ == "__main__":
    app.run(debug=True)